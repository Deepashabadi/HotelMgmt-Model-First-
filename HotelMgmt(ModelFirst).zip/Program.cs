﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelFirstExample
{
    class Program
    {
        
        
            /* Room ob = new Room();

             ob.name = "PINK";
             ob.description = "dkfghurjhj";
             ob.capacity = 5;
             ob.enabled = 1;
             ob.note = "Acquired";
             ob.smart = 1;
             ob.floor = 4;
             ob.BuildingIdBuilding = 2;
             string sqldepinsert = String.Format("insert into Rooms(name,description,capacity,enabled,note,smart,floor,BuildingIdBuilding)values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", ob.name, ob.description, ob.capacity, ob.enabled, ob.note, ob.smart, ob.floor, ob.BuildingIdBuilding);

             Console.WriteLine("QUERY \t" + sqldepinsert);
             ExModelContainer db = new ExModelContainer();
             int res = db.Database.ExecuteSqlCommand(sqldepinsert);
             if (res == 1)
                 Console.WriteLine("Query inserted");
             else
                 Console.WriteLine("ERROR in inserting data");*/

            public static void display(Room r)
            {
                Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}", r.IdRoom, r.name, r.description, r.capacity, r.enabled, r.note, r.smart, r.BuildingIdBuilding, r.floor);
            }
            public static Room getroomdata()
            {
                Room room = new Room();
                room.IdRoom = Convert.ToInt32(Console.ReadLine());
                room.name = Console.ReadLine();
                room.description = Console.ReadLine();
                room.capacity = Convert.ToInt32(Console.ReadLine());
                room.enabled = Convert.ToByte(Console.ReadLine());
                room.note = Console.ReadLine();
                room.smart = Convert.ToByte(Console.ReadLine());
                room.BuildingIdBuilding = Convert.ToInt32(Console.ReadLine());
                room.floor = Convert.ToInt32(Console.ReadLine());
                return room;
            }
            static void Main(string[] args)
            {
                //CREATE OBJ OF CONTEXT CLASS
                ExModelContainer db = new ExModelContainer();

                int choice, id;
                do
                {
                    Console.WriteLine("1 INSERT 2 DISPLAY 3 UPDATE 4 DELETE 5 EXIT");
                    choice = Convert.ToInt32(Console.ReadLine());
                    Room room = new Room();
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter Roomid,name,description,capacity,enabled,note,smart,Buildingid,floor");
                            room = getroomdata();
                            db.Rooms.Add(room);
                            db.SaveChanges();
                            break;
                        case 2:
                            Console.WriteLine("DISPLAY RECORD");
                            Console.WriteLine("----------------------------------------------");
                            foreach (Room r in db.Rooms)
                            {
                                display(r);
                            }
                            break;
                        case 3:
                            Console.WriteLine("UPDATE RECORD");
                            Console.WriteLine("Enter the Room Id");
                            id = Convert.ToInt32(Console.ReadLine());
                            room = db.Rooms.Find(id);
                            if (room == null)
                                Console.WriteLine(" Room Id NOT FOUND");
                            else
                            {
                                Console.WriteLine("Enter name,description,capacity,enabled,note,smart,Buildingid,floor");
                                room.name = Console.ReadLine();
                                room.description = Console.ReadLine();
                                room.capacity = Convert.ToInt32(Console.ReadLine());
                                room.enabled = Convert.ToByte(Console.ReadLine());
                                room.note = Console.ReadLine();
                                room.smart = Convert.ToByte(Console.ReadLine());
                                room.BuildingIdBuilding = Convert.ToInt32(Console.ReadLine());
                                room.floor = Convert.ToInt32(Console.ReadLine());


                                db.SaveChanges();
                            }
                            break;
                        case 4:
                            Console.WriteLine("DELETE RECORD");
                            Console.WriteLine("Enter the Room Id");
                            id = Convert.ToInt32(Console.ReadLine());
                            room = db.Rooms.Find(id);
                            if (room == null)
                                Console.WriteLine(" Room ID NOT FOUND");
                            else
                            {
                                db.Rooms.Remove(room);
                                db.SaveChanges();
                            }
                            break;
                        case 5: break;
                        default: Console.WriteLine("Invalid choicce"); break;
                    }
                } while (choice != 5);
            }
    }
}
